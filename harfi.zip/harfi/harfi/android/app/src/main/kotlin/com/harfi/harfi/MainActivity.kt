package com.harfi.harfi

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
