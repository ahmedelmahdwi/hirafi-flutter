import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../controllers/auth_controller.dart';

class ProfileView extends ConsumerWidget {
  const ProfileView({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final userAsync = ref.watch(authControllerProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('الملف الشخصي'),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            tooltip: 'تسجيل الخروج',
            onPressed: () async {
              await ref.read(authControllerProvider.notifier).logout();
              if (context.mounted) {
                context.go('/login');
              }
            },
          ),
        ],
      ),
      body: userAsync.when(
        data: (user) {
          if (user == null) {
            return const Center(child: Text('غير مسجل دخول'));
          }
          return Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                const CircleAvatar(
                  radius: 50,
                  child: Icon(Icons.person, size: 50),
                ),
                const SizedBox(height: 16),
                Text(
                  user.name,
                  style: Theme.of(context).textTheme.headlineSmall,
                ),
                Text(user.email, style: Theme.of(context).textTheme.bodyLarge),
                const SizedBox(height: 8),
                Chip(
                  label: Text(user.role == 'professional' ? 'حرفي' : 'عميل'),
                  backgroundColor: Theme.of(
                    context,
                  ).primaryColor.withValues(alpha: 0.1),
                ),
                const SizedBox(height: 16),
                if (user.phone != null && user.phone!.isNotEmpty)
                  ListTile(
                    leading: const Icon(Icons.phone),
                    title: Text('رقم الهاتف: ${user.phone}'),
                  ),
                if (user.role == 'professional') ...[
                  ListTile(
                    leading: const Icon(Icons.work),
                    title: Text('التخصص: ${user.category ?? "-"}'),
                  ),
                  ListTile(
                    leading: const Icon(Icons.info),
                    title: Text('نبذة: ${user.bio ?? "-"}'),
                  ),
                ],
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.edit),
                    label: const Text('تعديل الملف الشخصي'),
                    onPressed: () => context.push('/edit-profile'),
                  ),
                ),
              ],
            ),
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, st) => Center(child: Text('خطأ: $e')),
      ),
    );
  }
}
