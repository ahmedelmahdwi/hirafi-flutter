import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../controllers/home_controller.dart';
import '../../controllers/auth_controller.dart';
import '../../controllers/service_controller.dart';
import '../../core/constants.dart';

class HomeView extends ConsumerStatefulWidget {
  const HomeView({super.key});

  @override
  ConsumerState<HomeView> createState() => _HomeViewState();
}

class _HomeViewState extends ConsumerState<HomeView> {
  final _searchController = TextEditingController();
  final Set<String> _deletingServiceIds = {};

  @override
  Widget build(BuildContext context) {
    final userAsync = ref.watch(authControllerProvider);
    final user = userAsync.value;

    final professionalId = user?.role == 'professional' ? user?.uid : null;
    final servicesAsync = ref.watch(homeControllerProvider(professionalId));

    return Scaffold(
      appBar: AppBar(title: const Text('حرفي')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'ابحث عن خدمة...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.clear),
                  onPressed: () {
                    _searchController.clear();
                    ref
                        .read(homeControllerProvider(professionalId).notifier)
                        .fetchServices();
                  },
                ),
              ),
              onSubmitted: (val) {
                ref
                    .read(homeControllerProvider(professionalId).notifier)
                    .searchServices(val);
              },
            ),
          ),

          Consumer(
            builder: (context, ref, child) {
              final selectedCategory = ref.watch(
                selectedCategoryProvider(professionalId),
              );
              return SizedBox(
                height: 50,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  children: [
                    _CategoryChip(
                      'الكل',
                      isSelected: selectedCategory == null,
                      onTap: () {
                        ref
                            .read(
                              homeControllerProvider(professionalId).notifier,
                            )
                            .fetchServices();
                        ref
                            .read(
                              selectedCategoryProvider(professionalId).notifier,
                            )
                            .clear();
                      },
                    ),
                    ...AppConstants.serviceCategories.map(
                      (category) => _CategoryChip(
                        category,
                        isSelected: selectedCategory == category,
                        onTap: () {
                          ref
                              .read(
                                homeControllerProvider(professionalId).notifier,
                              )
                              .filterByCategory(category);
                          ref
                              .read(
                                selectedCategoryProvider(
                                  professionalId,
                                ).notifier,
                              )
                              .setCategory(category);
                        },
                      ),
                    ),
                  ],
                ),
              );
            },
          ),

          const SizedBox(height: 16),

          Expanded(
            child: servicesAsync.when(
              data: (services) {
                if (services.isEmpty) {
                  return const Center(
                    child: Text('لا توجد خدمات متاحة حالياً'),
                  );
                }
                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: services.length,
                  itemBuilder: (context, index) {
                    final service = services[index];
                    final isProfessionalViewingOwnService =
                        user?.role == 'professional' &&
                        user?.uid == service.professionalId;

                    return Card(
                      margin: const EdgeInsets.only(bottom: 16),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: Theme.of(
                            context,
                          ).primaryColor.withValues(alpha: 0.1),
                          child: Icon(
                            Icons.work,
                            color: Theme.of(context).primaryColor,
                          ),
                        ),
                        title: Text(service.title),
                        subtitle: Text(
                          '${service.category} • ${service.price} دينار ليبي',
                        ),
                        trailing: isProfessionalViewingOwnService
                            ? Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  IconButton(
                                    icon: const Icon(
                                      Icons.edit,
                                      color: Colors.blue,
                                    ),
                                    onPressed: () {
                                      context.push(
                                        '/edit-service',
                                        extra: {'service': service},
                                      );
                                    },
                                  ),
                                  _deletingServiceIds.contains(service.id)
                                      ? const Padding(
                                          padding: EdgeInsets.all(8.0),
                                          child: SizedBox(
                                            width: 20,
                                            height: 20,
                                            child: CircularProgressIndicator(
                                              strokeWidth: 2,
                                            ),
                                          ),
                                        )
                                      : IconButton(
                                          icon: const Icon(
                                            Icons.delete,
                                            color: Colors.red,
                                          ),
                                          onPressed: () async {
                                            final confirm = await showDialog<bool>(
                                              context: context,
                                              builder: (ctx) => AlertDialog(
                                                title: const Text('حذف الخدمة'),
                                                content: const Text(
                                                  'هل أنت متأكد من حذف هذه الخدمة؟',
                                                ),
                                                actions: [
                                                  TextButton(
                                                    onPressed: () =>
                                                        Navigator.pop(
                                                          ctx,
                                                          false,
                                                        ),
                                                    child: const Text('إلغاء'),
                                                  ),
                                                  TextButton(
                                                    onPressed: () =>
                                                        Navigator.pop(
                                                          ctx,
                                                          true,
                                                        ),
                                                    child: const Text('حذف'),
                                                  ),
                                                ],
                                              ),
                                            );

                                            if (confirm == true) {
                                              setState(() {
                                                _deletingServiceIds.add(
                                                  service.id,
                                                );
                                              });
                                              try {
                                                await ref
                                                    .read(
                                                      serviceControllerProvider
                                                          .notifier,
                                                    )
                                                    .deleteService(service.id);
                                                if (context.mounted) {
                                                  ScaffoldMessenger.of(
                                                    context,
                                                  ).showSnackBar(
                                                    const SnackBar(
                                                      content: Text(
                                                        'تم حذف الخدمة بنجاح',
                                                      ),
                                                    ),
                                                  );
                                                }
                                              } catch (e) {
                                                if (context.mounted) {
                                                  ScaffoldMessenger.of(
                                                    context,
                                                  ).showSnackBar(
                                                    SnackBar(
                                                      content: Text(
                                                        'فشل الحذف: $e',
                                                      ),
                                                    ),
                                                  );
                                                }
                                              } finally {
                                                if (mounted) {
                                                  setState(() {
                                                    _deletingServiceIds.remove(
                                                      service.id,
                                                    );
                                                  });
                                                }
                                              }
                                            }
                                          },
                                        ),
                                ],
                              )
                            : ElevatedButton(
                                onPressed: () {
                                  context.push(
                                    '/booking/${service.id}',
                                    extra: {
                                      'professionalId': service.professionalId,
                                      'price': service.price,
                                    },
                                  );
                                },
                                child: const Text('حجز'),
                              ),
                      ),
                    );
                  },
                );
              },
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, st) => Center(child: Text('حدث خطأ: $e')),
            ),
          ),
        ],
      ),
      floatingActionButton: user?.role == 'professional'
          ? FloatingActionButton(
              onPressed: () => context.push('/create-service'),
              tooltip: 'إضافة خدمة جديدة',
              child: const Icon(Icons.add),
            )
          : null,
    );
  }
}

class _CategoryChip extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final bool isSelected;

  const _CategoryChip(
    this.label, {
    required this.onTap,
    this.isSelected = false,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: 8.0),
      child: ActionChip(
        label: Text(label),
        onPressed: onTap,
        side: BorderSide(
          color: isSelected
              ? Theme.of(context).primaryColor
              : Colors.transparent,
          width: 2,
        ),
        backgroundColor: isSelected
            ? Theme.of(context).primaryColor.withValues(alpha: 0.1)
            : null,
      ),
    );
  }
}
