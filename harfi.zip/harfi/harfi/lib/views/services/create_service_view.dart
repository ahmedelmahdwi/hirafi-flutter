import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../controllers/service_controller.dart';
import '../../core/constants.dart';

class CreateServiceView extends ConsumerStatefulWidget {
  const CreateServiceView({super.key});

  @override
  ConsumerState<CreateServiceView> createState() => _CreateServiceViewState();
}

class _CreateServiceViewState extends ConsumerState<CreateServiceView> {
  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descController = TextEditingController();
  final _priceController = TextEditingController();
  final _locationController = TextEditingController();
  final _durationController = TextEditingController();
  final _availabilityNotesController = TextEditingController();
  String? _selectedCategory;
  bool _isLoading = false;

  @override
  void dispose() {
    _titleController.dispose();
    _descController.dispose();
    _priceController.dispose();
    _locationController.dispose();
    _durationController.dispose();
    _availabilityNotesController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إضافة خدمة جديدة')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: _titleController,
                decoration: const InputDecoration(labelText: 'عنوان الخدمة'),
                validator: (v) => v!.isEmpty ? 'مطلوب' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _descController,
                decoration: const InputDecoration(labelText: 'وصف الخدمة'),
                maxLines: 3,
                validator: (v) => v!.isEmpty ? 'مطلوب' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _priceController,
                decoration: const InputDecoration(
                  labelText: 'السعر (دينار ليبي)',
                ),
                keyboardType: TextInputType.number,
                validator: (v) => v!.isEmpty ? 'مطلوب' : null,
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                initialValue: _selectedCategory,
                decoration: const InputDecoration(labelText: 'التصنيف'),
                items: AppConstants.serviceCategories.map((category) {
                  return DropdownMenuItem(
                    value: category,
                    child: Text(category),
                  );
                }).toList(),
                onChanged: (val) {
                  setState(() {
                    _selectedCategory = val;
                  });
                },
                validator: (v) => v == null ? 'مطلوب' : null,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _locationController,
                decoration: const InputDecoration(
                  labelText: 'الموقع/العنوان (اختياري)',
                  prefixIcon: Icon(Icons.location_on),
                  hintText: 'مثال: طرابلس، حي الأندلس',
                ),
                maxLines: 2,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _durationController,
                decoration: const InputDecoration(
                  labelText: 'المدة المتوقعة (اختياري)',
                  prefixIcon: Icon(Icons.access_time),
                  hintText: 'مثال: ساعتان، 30 دقيقة',
                ),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _availabilityNotesController,
                decoration: const InputDecoration(
                  labelText: 'ملاحظات التوفر (اختياري)',
                  prefixIcon: Icon(Icons.calendar_today),
                  hintText: 'مثال: متاح في عطلة نهاية الأسبوع',
                ),
                maxLines: 2,
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _submit,
                  child: _isLoading
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            valueColor: AlwaysStoppedAnimation<Color>(
                              Colors.white,
                            ),
                          ),
                        )
                      : const Text('إضافة الخدمة'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _submit() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isLoading = true;
      });
      try {
        await ref
            .read(serviceControllerProvider.notifier)
            .addService(
              title: _titleController.text.trim(),
              description: _descController.text.trim(),
              price: double.parse(_priceController.text.trim()),
              category: _selectedCategory!,
              location: _locationController.text.trim().isEmpty
                  ? null
                  : _locationController.text.trim(),
              duration: _durationController.text.trim().isEmpty
                  ? null
                  : _durationController.text.trim(),
              availabilityNotes:
                  _availabilityNotesController.text.trim().isEmpty
                  ? null
                  : _availabilityNotesController.text.trim(),
            );
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('تم إضافة الخدمة بنجاح')),
          );
          context.pop();
        }
      } catch (e) {
        if (mounted) {
          ScaffoldMessenger.of(
            context,
          ).showSnackBar(SnackBar(content: Text('فشل الإضافة: $e')));
        }
      } finally {
        if (mounted) {
          setState(() {
            _isLoading = false;
          });
        }
      }
    }
  }
}
