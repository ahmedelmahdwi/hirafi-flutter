import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import '../../controllers/booking_controller.dart';
import '../../controllers/auth_controller.dart';
import '../../models/booking_model.dart';
import '../../models/user_model.dart';

class ProfessionalBookingsView extends ConsumerStatefulWidget {
  const ProfessionalBookingsView({super.key});

  @override
  ConsumerState<ProfessionalBookingsView> createState() =>
      _ProfessionalBookingsViewState();
}

class _ProfessionalBookingsViewState
    extends ConsumerState<ProfessionalBookingsView> {
  final Set<String> _updatingBookingIds = {};

  @override
  Widget build(BuildContext context) {
    final bookingsAsync = ref.watch(bookingControllerProvider);
    final user = ref.watch(authControllerProvider).value;

    return Scaffold(
      appBar: AppBar(title: const Text('إدارة الحجوزات')),
      body: bookingsAsync.when(
        data: (bookings) {
          final myBookings = bookings
              .where((b) => b.professionalId == user?.uid)
              .toList();

          if (myBookings.isEmpty) {
            return const Center(child: Text('لا توجد حجوزات'));
          }
          final sortedBookings = List<BookingModel>.from(myBookings)
            ..sort((a, b) => b.date.compareTo(a.date));

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: sortedBookings.length,
            itemBuilder: (context, index) {
              final booking = sortedBookings[index];
              return Card(
                margin: const EdgeInsets.only(bottom: 16),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'موعد: ${DateFormat('yyyy-MM-dd').format(booking.date)}',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 8),
                      Text('الحالة: ${_getStatusText(booking.status)}'),
                      const SizedBox(height: 16),
                      if (booking.status == 'pending')
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            _updatingBookingIds.contains(booking.id)
                                ? const Padding(
                                    padding: EdgeInsets.all(8.0),
                                    child: SizedBox(
                                      width: 20,
                                      height: 20,
                                      child: CircularProgressIndicator(
                                        strokeWidth: 2,
                                      ),
                                    ),
                                  )
                                : Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      TextButton(
                                        onPressed: () async {
                                          setState(() {
                                            _updatingBookingIds.add(booking.id);
                                          });
                                          try {
                                            await ref
                                                .read(
                                                  bookingControllerProvider
                                                      .notifier,
                                                )
                                                .updateBookingStatus(
                                                  booking.id,
                                                  'cancelled',
                                                );
                                            if (context.mounted) {
                                              ScaffoldMessenger.of(
                                                context,
                                              ).showSnackBar(
                                                const SnackBar(
                                                  content: Text('تم رفض الحجز'),
                                                ),
                                              );
                                            }
                                          } finally {
                                            if (mounted) {
                                              setState(() {
                                                _updatingBookingIds.remove(
                                                  booking.id,
                                                );
                                              });
                                            }
                                          }
                                        },
                                        style: TextButton.styleFrom(
                                          foregroundColor: Colors.red,
                                        ),
                                        child: const Text('رفض'),
                                      ),
                                      const SizedBox(width: 8),
                                      ElevatedButton(
                                        onPressed: () async {
                                          setState(() {
                                            _updatingBookingIds.add(booking.id);
                                          });
                                          try {
                                            await ref
                                                .read(
                                                  bookingControllerProvider
                                                      .notifier,
                                                )
                                                .updateBookingStatus(
                                                  booking.id,
                                                  'confirmed',
                                                );
                                            if (context.mounted) {
                                              ScaffoldMessenger.of(
                                                context,
                                              ).showSnackBar(
                                                const SnackBar(
                                                  content: Text(
                                                    'تم قبول الحجز',
                                                  ),
                                                ),
                                              );
                                            }
                                          } finally {
                                            if (mounted) {
                                              setState(() {
                                                _updatingBookingIds.remove(
                                                  booking.id,
                                                );
                                              });
                                            }
                                          }
                                        },
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: Colors.green,
                                        ),
                                        child: const Text('قبول'),
                                      ),
                                    ],
                                  ),
                          ],
                        ),
                      if (booking.status == 'confirmed')
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            ElevatedButton.icon(
                              onPressed: () => _openChat(context, booking, ref),
                              icon: const Icon(Icons.chat),
                              label: const Text('فتح المحادثة'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.blue,
                                foregroundColor: Colors.white,
                              ),
                            ),
                          ],
                        ),
                    ],
                  ),
                ),
              );
            },
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, st) => Center(child: Text('خطأ: $e')),
      ),
    );
  }

  String _getStatusText(String status) {
    switch (status) {
      case 'pending':
        return 'قيد الانتظار';
      case 'confirmed':
        return 'مؤكد';
      case 'completed':
        return 'مكتمل';
      case 'cancelled':
        return 'ملغي';
      default:
        return status;
    }
  }

  Future<void> _openChat(
    BuildContext context,
    BookingModel booking,
    WidgetRef ref,
  ) async {
    try {
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(booking.customerId)
          .get();

      if (!userDoc.exists) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('لم يتم العثور على المستخدم')),
          );
        }
        return;
      }

      final otherUser = UserModel.fromMap(userDoc.data()!);

      if (context.mounted) {
        context.push(
          '/chat/${booking.id}',
          extra: {'booking': booking, 'otherUser': otherUser},
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('خطأ في فتح المحادثة: $e')));
      }
    }
  }
}
