import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';
import '../../controllers/booking_controller.dart';
import '../../controllers/auth_controller.dart';
import '../../models/user_model.dart';
import '../../models/booking_model.dart';

class CustomerBookingsView extends ConsumerWidget {
  const CustomerBookingsView({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final bookingsAsync = ref.watch(bookingControllerProvider);
    final userAsync = ref.watch(authControllerProvider);
    final currentUserId = userAsync.value?.uid;

    return Scaffold(
      appBar: AppBar(title: const Text('حجوزاتي')),
      body: bookingsAsync.when(
        data: (bookings) {
          final customerBookings = bookings
              .where(
                (b) => currentUserId != null && b.customerId == currentUserId,
              )
              .toList();

          if (customerBookings.isEmpty) {
            return const Center(child: Text('لا توجد حجوزات'));
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: customerBookings.length,
            itemBuilder: (context, index) {
              final booking = customerBookings[index];
              final dateStr = DateFormat('yyyy-MM-dd').format(booking.date);

              String statusText;
              Color statusColor;
              switch (booking.status) {
                case 'confirmed':
                  statusText = 'مؤكد';
                  statusColor = Colors.green;
                  break;
                case 'completed':
                  statusText = 'مكتمل';
                  statusColor = Colors.blue;
                  break;
                case 'cancelled':
                  statusText = 'ملغي';
                  statusColor = Colors.red;
                  break;
                default:
                  statusText = 'قيد الانتظار';
                  statusColor = Colors.orange;
              }

              return Card(
                margin: const EdgeInsets.only(bottom: 16),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: statusColor.withValues(alpha: 0.2),
                    child: Icon(Icons.calendar_today, color: statusColor),
                  ),
                  title: Text('حجز - $dateStr'),
                  subtitle: Text('الوقت: ${booking.time}\nالحالة: $statusText'),
                  isThreeLine: true,
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (booking.status == 'confirmed')
                        IconButton(
                          icon: const Icon(Icons.chat),
                          onPressed: () => _openChat(context, booking, ref),
                          tooltip: 'فتح المحادثة',
                        ),
                      Chip(
                        label: Text(statusText),
                        backgroundColor: statusColor.withValues(alpha: 0.2),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, st) => Center(child: Text('خطأ: $e')),
      ),
    );
  }

  Future<void> _openChat(
    BuildContext context,
    BookingModel booking,
    WidgetRef ref,
  ) async {
    try {
      final userDoc = await FirebaseFirestore.instance
          .collection('users')
          .doc(booking.professionalId)
          .get();

      if (!userDoc.exists) {
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('لم يتم العثور على المستخدم')),
          );
        }
        return;
      }

      final otherUser = UserModel.fromMap(userDoc.data()!);

      if (context.mounted) {
        context.push(
          '/chat/${booking.id}',
          extra: {'booking': booking, 'otherUser': otherUser},
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('خطأ في فتح المحادثة: $e')));
      }
    }
  }
}
