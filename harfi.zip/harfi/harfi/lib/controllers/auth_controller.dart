import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';
import '../models/user_model.dart';

final authControllerProvider =
    StateNotifierProvider<AuthController, AsyncValue<UserModel?>>((ref) {
      return AuthController(FirebaseAuth.instance, FirebaseFirestore.instance);
    });

class AuthController extends StateNotifier<AsyncValue<UserModel?>> {
  final FirebaseAuth _auth;
  final FirebaseFirestore _firestore;

  AuthController(this._auth, this._firestore)
    : super(const AsyncValue.data(null)) {
    _checkCurrentUser();
  }

  Future<void> _checkCurrentUser() async {
    final user = _auth.currentUser;
    if (user != null) {
      await _loadUserData(user.uid);
    }
  }

  Future<void> _loadUserData(String uid) async {
    state = const AsyncValue.loading();
    try {
      final doc = await _firestore.collection('users').doc(uid).get();
      if (doc.exists) {
        final userModel = UserModel.fromMap(doc.data()!);
        state = AsyncValue.data(userModel);
      } else {
        state = const AsyncValue.data(null);
      }
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }

  Future<void> login(String email, String password) async {
    state = const AsyncValue.loading();
    try {
      final creds = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      await _loadUserData(creds.user!.uid);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
      rethrow;
    }
  }

  Future<void> register({
    required String email,
    required String password,
    required String name,
    required String phone,
    required String role,
    String? category,
    String? bio,
  }) async {
    state = const AsyncValue.loading();
    try {
      final creds = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      final uid = creds.user!.uid;

      final newUser = UserModel(
        uid: uid,
        email: email,
        name: name,
        phone: phone,
        role: role,
        category: category,
        bio: bio,
      );

      await _firestore.collection('users').doc(uid).set(newUser.toMap());
      state = AsyncValue.data(newUser);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
      rethrow;
    }
  }

  Future<void> updateProfile({
    required String name,
    required String phone,
    String? category,
    String? bio,
  }) async {
    final currentUser = state.value;
    if (currentUser == null) return;

    state = const AsyncValue.loading();
    try {
      final updatedUser = UserModel(
        uid: currentUser.uid,
        email: currentUser.email,
        name: name,
        phone: phone,
        role: currentUser.role,
        profileImage: currentUser.profileImage,
        category: category,
        bio: bio,
      );

      await _firestore
          .collection('users')
          .doc(currentUser.uid)
          .update(updatedUser.toMap());
      state = AsyncValue.data(updatedUser);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
      rethrow;
    }
  }

  Future<void> logout() async {
    await _auth.signOut();
    state = const AsyncValue.data(null);
  }
}
