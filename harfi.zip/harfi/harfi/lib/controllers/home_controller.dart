import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';
import '../models/service_model.dart';

final homeControllerProvider =
    StateNotifierProvider.family<
      HomeController,
      AsyncValue<List<ServiceModel>>,
      String?
    >((ref, professionalId) {
      return HomeController(FirebaseFirestore.instance, professionalId);
    });

final selectedCategoryProvider =
    StateNotifierProvider.family<SelectedCategoryNotifier, String?, String?>((
      ref,
      professionalId,
    ) {
      return SelectedCategoryNotifier();
    });

class SelectedCategoryNotifier extends StateNotifier<String?> {
  SelectedCategoryNotifier() : super(null);

  void setCategory(String? category) {
    state = category;
  }

  void clear() {
    state = null;
  }
}

class HomeController extends StateNotifier<AsyncValue<List<ServiceModel>>> {
  final FirebaseFirestore _firestore;
  final String? _professionalId;
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _subscription;
  String? _currentSearchQuery;
  String? _currentCategoryFilter;
  List<ServiceModel>? _allServices;

  String? get selectedCategory => _currentCategoryFilter;

  HomeController(this._firestore, this._professionalId)
    : super(const AsyncValue.loading()) {
    _listenToServices();
  }

  void _listenToServices() {
    if (_subscription != null) return;

    state = const AsyncValue.loading();
    Query<Map<String, dynamic>> query = _firestore.collection('services');

    if (_professionalId != null) {
      query = query.where('professionalId', isEqualTo: _professionalId);
    }

    _subscription = query.snapshots().listen(
      (snapshot) {
        _allServices = snapshot.docs
            .map((doc) => ServiceModel.fromMap(doc.data(), doc.id))
            .toList();

        _applyFilters();
      },
      onError: (e, st) {
        state = AsyncValue.error(e, st);
      },
    );
  }

  void _applyFilters() {
    if (_allServices == null) return;

    var filtered = List<ServiceModel>.from(_allServices!);

    if (_currentCategoryFilter != null && _currentCategoryFilter!.isNotEmpty) {
      filtered = filtered
          .where((s) => s.category == _currentCategoryFilter)
          .toList();
    }

    if (_currentSearchQuery != null && _currentSearchQuery!.isNotEmpty) {
      filtered = filtered
          .where(
            (s) =>
                s.title.toLowerCase().contains(
                  _currentSearchQuery!.toLowerCase(),
                ) ||
                s.category.toLowerCase().contains(
                  _currentSearchQuery!.toLowerCase(),
                ),
          )
          .toList();
    }

    state = AsyncValue.data(filtered);
  }

  Future<void> fetchServices() async {
    _currentSearchQuery = null;
    _currentCategoryFilter = null;
    _applyFilters();
  }

  Future<void> filterByCategory(String? category) async {
    _currentCategoryFilter = category;
    _applyFilters();
  }

  Future<void> searchServices(String query) async {
    _currentSearchQuery = query.isEmpty ? null : query;
    _applyFilters();
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }
}
