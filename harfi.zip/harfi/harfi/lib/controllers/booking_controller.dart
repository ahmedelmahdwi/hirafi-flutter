import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';
import '../models/booking_model.dart';
import 'auth_controller.dart';

final bookingControllerProvider =
    StateNotifierProvider<BookingController, AsyncValue<List<BookingModel>>>(
  (ref) {
    final user = ref.watch(authControllerProvider).value;
    return BookingController(FirebaseFirestore.instance, user?.uid);
  },
);

class BookingController extends StateNotifier<AsyncValue<List<BookingModel>>> {
  final FirebaseFirestore _firestore;
  final String? _userId;
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _subscription;

  BookingController(this._firestore, this._userId)
      : super(const AsyncValue.loading()) {
    if (_userId != null) {
      _listenToBookings();
    } else {
      state = const AsyncValue.data([]);
    }
  }

  void _listenToBookings() {
    state = const AsyncValue.loading();
    _subscription = _firestore
        .collection('bookings')
        .where('participants', arrayContains: _userId)
        .snapshots()
        .listen(
      (snapshot) {
        final bookings = snapshot.docs
            .map((doc) => BookingModel.fromMap(doc.data(), doc.id))
            .toList();
        state = AsyncValue.data(bookings);
      },
      onError: (e, st) {
        state = AsyncValue.error(e, st);
      },
    );
  }

  Future<void> fetchBookings() async {
    if (_userId == null) return;
    try {
      final query = await _firestore
          .collection('bookings')
          .where('participants', arrayContains: _userId)
          .get();

      final bookings = query.docs
          .map((doc) => BookingModel.fromMap(doc.data(), doc.id))
          .toList();
      state = AsyncValue.data(bookings);
    } catch (e, st) {
      state = AsyncValue.error(e, st);
    }
  }

  Future<void> createBooking({
    required String professionalId,
    required String serviceId,
    required DateTime date,
    required String time,
    String? customerNotes,
    String? serviceAddress,
  }) async {
    if (_userId == null) throw Exception('User not logged in');
    
    state = const AsyncValue.loading();
    try {
      final newBooking = BookingModel(
        id: '', // Firestore will generate
        customerId: _userId,
        professionalId: professionalId,
        serviceId: serviceId,
        date: date,
        time: time,
        status: 'pending',
        customerNotes: customerNotes,
        serviceAddress: serviceAddress,
      );

      await _firestore.collection('bookings').add(newBooking.toMap());
    } catch (e, st) {
      state = AsyncValue.error(e, st);
      rethrow;
    }
  }

  Future<void> updateBookingStatus(String bookingId, String status) async {
    state = const AsyncValue.loading();
    try {
      await _firestore
          .collection('bookings')
          .doc(bookingId)
          .update({'status': status});
    } catch (e, st) {
      state = AsyncValue.error(e, st);
      rethrow;
    }
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }
}
