import 'dart:async';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_riverpod/legacy.dart';
import '../models/chat_message_model.dart';
import 'auth_controller.dart';

final chatControllerProvider =
    StateNotifierProvider.family<
      ChatController,
      AsyncValue<List<ChatMessage>>,
      String
    >((ref, bookingId) {
      final user = ref.watch(authControllerProvider).value;
      return ChatController(FirebaseFirestore.instance, bookingId, user?.uid);
    });

class ChatController extends StateNotifier<AsyncValue<List<ChatMessage>>> {
  final FirebaseFirestore _firestore;
  final String _bookingId;
  final String? _userId;
  StreamSubscription<QuerySnapshot<Map<String, dynamic>>>? _subscription;

  ChatController(this._firestore, this._bookingId, this._userId)
    : super(const AsyncValue.loading()) {
    if (_userId != null) {
      _listenToMessages();
    } else {
      state = const AsyncValue.data([]);
    }
  }

  void _listenToMessages() {
    state = const AsyncValue.loading();
    _subscription = _firestore
        .collection('chats')
        .doc(_bookingId)
        .collection('messages')
        .orderBy('timestamp', descending: false)
        .snapshots()
        .listen(
          (snapshot) {
            final messages = snapshot.docs
                .where((doc) => doc.data()['timestamp'] != null)
                .map((doc) => ChatMessage.fromMap(doc.data(), doc.id))
                .toList();
            state = AsyncValue.data(messages);
            _markMessagesAsRead();
          },
          onError: (e, st) {
            state = AsyncValue.error(e, st);
          },
        );
  }

  Future<void> _markMessagesAsRead() async {
    if (_userId == null) return;
    final messages = state.value;
    if (messages == null) return;

    final unreadMessages = messages
        .where((m) => m.receiverId == _userId && !m.isRead)
        .toList();

    for (final msg in unreadMessages) {
      await _firestore
          .collection('chats')
          .doc(_bookingId)
          .collection('messages')
          .doc(msg.id)
          .update({'isRead': true});
    }
  }

  Future<void> sendMessage({
    required String receiverId,
    required String message,
  }) async {
    if (_userId == null) throw Exception('User not logged in');
    if (message.trim().isEmpty) return;

    try {
      await _firestore
          .collection('chats')
          .doc(_bookingId)
          .collection('messages')
          .add({
            'bookingId': _bookingId,
            'senderId': _userId,
            'receiverId': receiverId,
            'message': message.trim(),
            'timestamp': FieldValue.serverTimestamp(),
            'isRead': false,
          });
    } catch (e, st) {
      state = AsyncValue.error(e, st);
      rethrow;
    }
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }
}
