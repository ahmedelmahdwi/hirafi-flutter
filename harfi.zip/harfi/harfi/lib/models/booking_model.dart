import 'package:cloud_firestore/cloud_firestore.dart';

class BookingModel {
  final String id;
  final String customerId;
  final String professionalId;
  final String serviceId;
  final DateTime date;
  final String time; // Time/hour of the appointment (e.g., "10:00", "14:30")
  final String status; // 'pending', 'confirmed', 'completed', 'cancelled'
  final String? customerNotes; // Customer's notes/requirements
  final String? serviceAddress; // Address where service will be performed

  BookingModel({
    required this.id,
    required this.customerId,
    required this.professionalId,
    required this.serviceId,
    required this.date,
    required this.time,
    required this.status,
    this.customerNotes,
    this.serviceAddress,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'customerId': customerId,
      'professionalId': professionalId,
      'serviceId': serviceId,
      'date': Timestamp.fromDate(date),
      'time': time,
      'status': status,
      'participants': [customerId, professionalId],
      'customerNotes': customerNotes,
      'serviceAddress': serviceAddress,
    };
  }

  factory BookingModel.fromMap(Map<String, dynamic> map, String id) {
    return BookingModel(
      id: id,
      customerId: map['customerId'] ?? '',
      professionalId: map['professionalId'] ?? '',
      serviceId: map['serviceId'] ?? '',
      date: (map['date'] as Timestamp).toDate(),
      time: map['time'] ?? '',
      status: map['status'] ?? 'pending',
      customerNotes: map['customerNotes'],
      serviceAddress: map['serviceAddress'],
    );
  }
}
