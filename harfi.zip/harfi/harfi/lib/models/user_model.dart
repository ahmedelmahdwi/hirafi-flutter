class UserModel {
  final String uid;
  final String email;
  final String name;
  final String role; // 'customer' or 'professional'
  final String? phone;
  final String? profileImage;
  final String? bio; // For professionals
  final String? category; // For professionals (e.g., 'Plumber', 'Electrician')

  UserModel({
    required this.uid,
    required this.email,
    required this.name,
    required this.role,
    this.phone,
    this.profileImage,
    this.bio,
    this.category,
  });

  Map<String, dynamic> toMap() {
    return {
      'uid': uid,
      'email': email,
      'name': name,
      'role': role,
      'phone': phone,
      'profileImage': profileImage,
      'bio': bio,
      'category': category,
    };
  }

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      uid: map['uid'] ?? '',
      email: map['email'] ?? '',
      name: map['name'] ?? '',
      role: map['role'] ?? 'customer',
      phone: map['phone'],
      profileImage: map['profileImage'],
      bio: map['bio'],
      category: map['category'],
    );
  }
}
