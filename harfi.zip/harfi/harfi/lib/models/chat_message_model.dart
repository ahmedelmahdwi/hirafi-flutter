import 'package:cloud_firestore/cloud_firestore.dart';

class ChatMessage {
  final String id;
  final String bookingId;
  final String senderId;
  final String receiverId;
  final String message;
  final DateTime timestamp;
  final bool isRead;

  ChatMessage({
    required this.id,
    required this.bookingId,
    required this.senderId,
    required this.receiverId,
    required this.message,
    required this.timestamp,
    this.isRead = false,
  });

  Map<String, dynamic> toMap() {
    return {
      'bookingId': bookingId,
      'senderId': senderId,
      'receiverId': receiverId,
      'message': message,
      'timestamp': Timestamp.fromDate(timestamp),
      'isRead': isRead,
    };
  }

  factory ChatMessage.fromMap(Map<String, dynamic> map, String id) {
    Timestamp? timestampValue = map['timestamp'] as Timestamp?;
    DateTime timestamp;
    if (timestampValue != null) {
      timestamp = timestampValue.toDate();
    } else {
      timestamp = DateTime.now();
    }

    return ChatMessage(
      id: id,
      bookingId: map['bookingId'] ?? '',
      senderId: map['senderId'] ?? '',
      receiverId: map['receiverId'] ?? '',
      message: map['message'] ?? '',
      timestamp: timestamp,
      isRead: map['isRead'] ?? false,
    );
  }
}
