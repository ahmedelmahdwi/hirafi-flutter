class ServiceModel {
  final String id;
  final String professionalId;
  final String title;
  final String description;
  final double price;
  final String category;
  final String? location; // Service location/address
  final String? duration; // Estimated duration (e.g., "2 hours", "30 minutes")
  final String?
  availabilityNotes; // Availability notes (e.g., "Available on weekends")

  ServiceModel({
    required this.id,
    required this.professionalId,
    required this.title,
    required this.description,
    required this.price,
    required this.category,
    this.location,
    this.duration,
    this.availabilityNotes,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'professionalId': professionalId,
      'title': title,
      'description': description,
      'price': price,
      'category': category,
      'location': location,
      'duration': duration,
      'availabilityNotes': availabilityNotes,
    };
  }

  factory ServiceModel.fromMap(Map<String, dynamic> map, String id) {
    return ServiceModel(
      id: id,
      professionalId: map['professionalId'] ?? '',
      title: map['title'] ?? '',
      description: map['description'] ?? '',
      price: (map['price'] ?? 0).toDouble(),
      category: map['category'] ?? '',
      location: map['location'],
      duration: map['duration'],
      availabilityNotes: map['availabilityNotes'],
    );
  }
}
