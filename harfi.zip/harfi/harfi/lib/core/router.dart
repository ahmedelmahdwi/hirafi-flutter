import 'package:go_router/go_router.dart';
import '../views/auth/login_view.dart';
import '../views/auth/register_view.dart';
import '../views/main/main_scaffold.dart';
import '../views/booking/booking_view.dart';
import '../views/booking/professional_bookings_view.dart';
import '../views/booking/customer_bookings_view.dart';
import '../views/services/my_services_view.dart';
import '../views/services/create_service_view.dart';
import '../views/profile/profile_view.dart';
import '../views/profile/edit_profile_view.dart';
import '../views/intro/splash_view.dart';
import '../views/intro/onboarding_view.dart';
import '../views/chat/chat_view.dart';
import '../views/services/edit_service_view.dart';
import '../models/booking_model.dart';
import '../models/user_model.dart';
import '../models/service_model.dart';
import 'prefs_service.dart';

final router = GoRouter(
  initialLocation: '/splash',
  routes: [
    GoRoute(path: '/splash', builder: (context, state) => const SplashView()),
    GoRoute(
      path: '/onboarding',
      redirect: (context, state) async {
        final isCompleted = await PrefsService.isOnboardingCompleted();
        if (isCompleted) {
          return '/login';
        }
        return null;
      },
      builder: (context, state) => const OnboardingView(),
    ),
    GoRoute(path: '/login', builder: (context, state) => const LoginView()),
    GoRoute(path: '/home', builder: (context, state) => const MainScaffold()),
    GoRoute(
      path: '/register',
      builder: (context, state) => const RegisterView(),
    ),
    GoRoute(
      path: '/booking/:serviceId',
      builder: (context, state) {
        final serviceId = state.pathParameters['serviceId']!;
        final extra = state.extra as Map<String, dynamic>;
        return BookingView(
          serviceId: serviceId,
          professionalId: extra['professionalId'],
          price: extra['price'],
        );
      },
    ),
    GoRoute(path: '/profile', builder: (context, state) => const ProfileView()),
    GoRoute(
      path: '/edit-profile',
      builder: (context, state) => const EditProfileView(),
    ),
    GoRoute(
      path: '/professional-bookings',
      builder: (context, state) => const ProfessionalBookingsView(),
    ),
    GoRoute(
      path: '/customer-bookings',
      builder: (context, state) => const CustomerBookingsView(),
    ),
    GoRoute(
      path: '/my-services',
      builder: (context, state) => const MyServicesView(),
    ),
    GoRoute(
      path: '/create-service',
      builder: (context, state) => const CreateServiceView(),
    ),
    GoRoute(
      path: '/edit-service',
      builder: (context, state) {
        final extra = state.extra as Map<String, dynamic>;
        return EditServiceView(
          service: extra['service'] as ServiceModel,
        );
      },
    ),
    GoRoute(
      path: '/chat/:bookingId',
      builder: (context, state) {
        final extra = state.extra as Map<String, dynamic>;
        return ChatView(
          booking: extra['booking'] as BookingModel,
          otherUser: extra['otherUser'] as UserModel,
        );
      },
    ),
  ],
);
