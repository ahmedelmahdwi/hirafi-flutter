class AppConstants {
  static const String appName = 'Harfi';
  static const String currency = 'lyd';
  
  static const List<String> serviceCategories = [
    'نجارة',
    'سباكة',
    'كهرباء',
    'حدادة',
    'دهان وديكور',
    'تركيب سيراميك وبلاط',
    'تكييف وتبريد',
    'صيانة عامة',
    'ألوميتال',
    'جبس بورد',
    'إصلاح أجهزة منزلية',
  ];
}
